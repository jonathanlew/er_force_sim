#ifndef SERIALIZE_SETUP_H
#define SERIALIZE_SETUP_H

class CommonExampleInterface*    SerializeBulletCreateFunc(struct CommonExampleOptions& options);


#endif //SERIALIZE_SETUP_H
