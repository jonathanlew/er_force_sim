#ifndef CONSTAINT_PHYSICS_SETUP_H
#define CONSTAINT_PHYSICS_SETUP_H

class CommonExampleInterface*    ConstraintCreateFunc(struct CommonExampleOptions& options);

#endif //CONSTAINT_PHYSICS_SETUP_H
