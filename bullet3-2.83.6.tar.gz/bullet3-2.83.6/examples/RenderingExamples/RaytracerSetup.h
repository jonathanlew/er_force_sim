#ifndef RAYTRACER_SETUP_H
#define RAYTRACER_SETUP_H

class CommonExampleInterface*    RayTracerCreateFunc(struct CommonExampleOptions& options);

#endif //RAYTRACER_SETUP_H
